/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	machine.h
 *  Sccsid:	@(#)machine.h	5.1.1.2	8/9/88  15:59:35
 *  Description:
 *		Machine specific definitions.
 *		Defines in this file should be turned ON and OFF
 *		simply by removing or inserting an uncommented
 *		version of the define before the commented define.
 *
 ***************************************************************************
 */


/***********************************************************************
 *
 * EIGHT BIT VERSIONS 
 *
 * use this define if the version is to allow all 8 bits for identifer
 * and data characters
 *
 ***********************************************************************/

#define EIGHTBIT 		/* -- eight-bit version of informix */

/************************************************************************
 *
 * Define one of the following to select the desired locking mechanism.
 */

#define SYS5LOCK

/* #define MSNET		-- locking for pc's 		*/
/* #define ONIXLOCK		-- onix locking() system call	*/
/* #define CREATLOCK		-- create ".lok" file		*/
/* #define DRVRLOCK		-- use special lock driver	*/
/* #define MEMLOCK 		-- keep lock info in memory	*/
/* #define NOLOCK  		-- no locking, single user	*/
/* #define RDSLOCK 		-- rds locking for kernel	*/
/* #define SEMLOCK 		-- System V semaphore locking	*/
/* #define SHMLOCK		-- System V shared memory lock	*/
/* #define SHMBUFF		-- System V shared memory buffers*/
/* #define SYS5LOCK		-- System V fcntl locking	*/
/* #define ISKERNEL		-- kernel installation flag	*/

/************************************************************************
 *
 *  Informix-TURBO Defines
 *
 * For Shared Memory without assembly language routines
 * define MACROSEMA for shared memory semaphores.
 */

/* #define MACROSEMA		-- C-macro semaphores		*/

/*
 * Pick one of the following page sizes:
 *	1024, 2048, 4096, 8192
 */

#define PAGESIZE 2048

/*
 * SHMBASE is the base address of shared memory
 *  most machines use 0x300000 (3 megabytes)
 *  others need 0x80000 (1/2 megabyte)
 */

#define SHMBASE 0x300000

/************************************************************************
 *
 * Define Terminal I/O Specific Flags.
 */

#define SYS3TTY

/* #define VER7TTY 		-- UNIX Version 7 tty driver	*/
/* #define SYS3TTY 		-- UNIX System III tty driver	*/
/* #define PCDOSTTY		-- PCDOS special terminal (include PCDOS)
				   LEAVE OUT for generic MSDOS port*/

/************************************************************************
 *
 * Define the default printer file name.
 */

#define DEFPRINT "lp -s"

/* #define DEFPRINT "lpr"	-- Most common one		*/   
/* #define DEFPRINT "lp -s" 	-- System V			*/
/* #define DEFPRINT "lpt1"	-- PCDOS			*/
/* #define DEFPRINT "print"	-- PC/IX			*/
/* #define DEFPRINT "$printer"  -- VMS                          */

/************************************************************************
 *
 * Define the default editor file name.
 */

#define DEFEDIT "vi"

/* #define DEFEDIT "vi"		-- Most common one		*/   
/* #define DEFEDIT "e" 		-- PC/IX e (INed)		*/
/* #define DEFEDIT "edit/tpu"   -- VMS                          */
/* #define DEFEDIT "edline"	-- pcdos

/************************************************************************
 *
 * Define Operating System Specific Flags.
 */

/* #define BERK4_2		-- Berkeley UNIX 4.2		*/
/* #define SEQUENT   		-- SEQUENT Operating System	*/
/* #define ZILOG   		-- ZEUS Operating System	*/
/* #define FORTUNE		-- FORTUNE Operating System	*/
/* #define CROMIX   		-- CROMIX Operating System	*/
/* #define PCDOS   		-- MS-DOS Operating System	*/
/* #define UNOS    		-- UNOS Operating System	*/
/* #define BBN			-- BBN Machine has 10 bits/byte	*/
/* #define PCIX			-- PC/IX Operating System	*/
/* #define VMS			-- VAX/VMS			*/


/*****************************************************************
 *  
 *  MODELS
 *
 * use this define if the machine will have dual large/medium models
 * for esqlc.
 * this will affect the code produced by i4gl in terms of the libraries
 * it links in and the compiler switches.
 * MOST LIKELY, this will be an xenix port or other 286 things
 *
 *******************************************************************/

/* #define MODELS		--dual large/medium models 	*/


/***********************************************************************
 * *******IMPORTANT********
 * Define whether or not machine is a "small system", with 64k addressable
 *  	data space.  This shrinks the number of isam buffers from 16 to
 *	8, and the node size from 1024 to 512
 * 	note -- xenix systems tend to be smallsys machines
 *	NOTE:  medium model compilation does not increase data space.
 *	       large model (if done) will do so
 *      However, define SMALLSYS even for large models, because
 *      a large model shipment will invariably be shipped in addition to
 *	a medium model, and BOTH models must run the same isam files,
 *      so if SMALLSYS is defined in medium, it must be defined in large.
 */

 /* #define SMALLSYS		-- define this if it is "small system"	*/


/************************************************************************
 *
 * Define Index Buffer Node Size (probably should be power of two)
 *
 * For VMS systems, NODESIZE must be a multiple of 512
 */

#define NODESIZE 1024

/* #define NODESIZE 512		-- 512 byte blocks		*/
/* #define NODESIZE 1024	-- 1024 byte blocks		*/
/* #define NODESIZE 2048	-- 2048 byte blocks		*/
/* #define NODESIZE 4096	-- 4096 byte blocks		*/


/************************************************************************
 *
 * Define Miscellaneous System Specific Flags.
 */

#ifdef PCDOS
#ifndef CVTFLOAT
#define NOFLOAT
#endif
#endif

#define ISALLOC
#define ISBUFHASH
#define ISBUFDATA
/* #define ISXACTION */
#define SCCSID
#define ISPCLOSE
#define NOFTIME

#ifdef BERK4_2
#define SOCKETS
#endif
#ifdef SOCKETS
#define NET
#endif
#ifdef TLI
#define NET
#endif

/* #define ISALLOC 		-- dynamic buffer allocation	*/
/* #define ISBUFHASH		-- do buffer hashing for lookup	*/
/* #define ISBUFDATA		-- do data record buffering	*/
/* #define ISXACTION		-- do logical transactions	*/
/* #define ISPCLOSE		-- do pseudo closes	 	*/
/* #define ISXBATCH		-- do extended batching 	*/
/* #define NOFTIME 		-- ftime() system call missing	*/
/* #define NOAUDIT 		-- no audit trail code		*/
/* #define NOFLOAT 		-- no float or double types	*/
/* #define NOCASTS 		-- C-compiler has no casts	*/
/* #define NOLONGMULT		-- use software long multiply	*/
/* #define NOATOF		-- no atof() in C library (very rare) */
/* #define NOVALIDATE		-- no serial number validation	*/
/* #define CUSTCOLL		-- enable custom collating table*/
/* #define COBOL   		-- Special COBOL features	*/
/* #define SCCSID		-- SCCS ID will be in objects	*/
/* #define SOCKETS		-- BSD4.2 style network sockets */
/* #define TLI			-- Sys 5.2 TLI network interface */
/* #define NET			-- Some type of network         */
/* #define NFS			-- Machine supports nfs	        */


/************************************************************************
 *    The following section contains defines used in order to invoke
 *  special fixes for bugs found during the porting process.  The bugs
 *  will not necessarily be found on any particular port, but some have
 *  been known to affect a class of machines.  The macros should not be
 *  defined unless the bug exists.  After compilation, test for these
 *  bugs, and if any exist, then the corresponding macro should be defined
 *  and the source recompiled.  The define macros themselves are based on
 *  the Bug numbers generated by PTS. For more information about a bug, 
 *  please use PTS with the number in the macro.
 *
 */

/* #define B3471 -  fglpc core dumps when retrieving data from db */


/******************************************************************
 * 	When defined, the following means that isql, ised, apsql,
 *	arsql, e3, and fm will be seperate programs, called
 *	by exec's from isql.
 *	This define will most likely be needed only on "small" machines
 *	(xenix??) which cannot handle massive programs over 300k bytes 
 *	easily.
 */
/* #define VEZPIECES		-- isql is broken up into pieces */


/************************************************************************
 *
 * The following defines relate to the closing
 * of files on an exec() system call.
 * If either of the first two are available, they should be used.
 * The first is used on systems which derive from Version 7.
 * The second is used on systems from System III.
 * The third is usable on any system, but does not insure closing
 * of C-ISAM files across an exec() call.
 */

#ifdef  VER7TTY
#ifdef  BERK4_2
#define CLOSEXEC(fd) fcntl((fd),_F_SETFD,1)	/* Berkeley 4.2	*/
#define _F_SETFD     2
#else
#define CLOSEXEC(fd) ioctl((fd),_FIOCLEX,0)	/* Version 7	*/
#define _FIOCLEX     (('f'<<8)|1)
#endif
#endif  /* VER7TTY */

#ifdef  SYS3TTY
#define CLOSEXEC(fd) fcntl((fd),_F_SETFD,1)	/* System III	*/
#define _F_SETFD     2
#endif  /* SYS3TTY */

#ifndef CLOSEXEC
#define CLOSEXEC(fd)				/* All others	*/
#endif  /* CLOSEXEC */


/************************************************************************
 *
 * Define miscellaneous system-specific values and resources.
 */

#ifdef	BBN			/* BBN Machine has 10 bits/byte	*/
				/* !! be sure to edit isam.h !!	*/
#define BYTEMASK  0x3FF		/* mask for one byte		*/
#define BYTESHFT  10		/* shift for one byte		*/
#else
#define BYTEMASK  0xFF		/* mask for one byte		*/
#define BYTESHFT  8		/* shift for one byte		*/
#endif	/* BBN */

/************************************************************************
 *
 * Define routines as macros for certain machine architectures
 */

#ifndef VMS
#if mc68020 || mc68k32 || u370 || UTS
#define ldint(p)	(*(short *)(p))
#define stint(i,p)	(*(short *)(p)=(i))
#define ldlong(p)	(*(long *)(p))
#define stlong(l,p)	(*(long *)(p)=(l))
#endif

#if mc68020 || mc68k32 || u370 || vax || UTS
#define ldfloat(p)	(*(float *)(p))
#define stfloat(f,p)	(*(float *)(p)=(f))
#define lddbl(p)	(*(double *)(p))
#define stdbl(d,p)	(*(double *)(p)=(d))
#endif
#endif /* VMS */

#ifdef VMS
#define ldfloat(p)	(*(float *)(p))
#define stfloat(f,p)	(*(float *)(p)=(f))
#define lddbl(p)	(*(double *)(p))
#define stdbl(d,p)	(*(double *)(p)=(d))
#endif /* VMS */

#ifdef	PCIX
#define ldint	ldshort
#define stint 	stshort
#define locking	lockf
#endif	/* PCIX */


#define MAXINT		2147483647L	/* maximum integer size */
#define MAXSMINT	32767		/* maximum smallint size */
#define INTNULL		0x80000000
#define SMINTNULL	-32768
#define CHARNULL	0


#ifdef NOSTRUCTASG
#define structasg(from, to)		{ bycopy(CASTCP from, CASTCP to,\
					    sizeof(*to)); }
#else
#define structasg(from, to)		{ *to = *from; }
#endif /* NOSTRUCTASG */

#ifdef VMS
#define unlink delete
#endif /* VMS */

/*	Machine Floating Point Type
 *      This is only used by network versions. It should identify the
 *	floating point representation on this machine.  Machines
 *	with the same representation (including byte order) should
 *	have the same value defined for FLTTYPE.  Machines with
 *	different representation MUST have different values for
 *      FLTTYPE or be defined as "".  There are a few standard 
 *      types.
 *
 *      IEEEM  - IEEE Motorola byte order 
 *      IEEEI  - IEEE Intel byte order
 */
#define FLTTYPE "IEEEM"
#ifdef sun
#ifdef mc68000
#define FLTTYPE "IEEEM"
#endif /* mc68000 */
#endif /* sun */

#ifdef APOLLO
#define FLTTYPE "APOLLO"
#endif /* APOLLO */

#ifndef FLTTYPE
#define FLTTYPE ""
#endif
