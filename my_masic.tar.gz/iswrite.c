/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	iswrite.c
 *  Sccsid:	@(#)iswrite.c	5.1.1.1	8/27/87  19:27:51
 *  Description:
 *		iswrite()	-- write record to C-ISAM file
 *		iswrcurr()	-- write record and make it current
 *		isrewrite()	-- update record of C-ISAM file
 *		isrewcurr()	-- update current record
 *		isrewrec()	-- update record by record number
 *		isdelete()	-- delete record of C-ISAM file
 *		isdelcurr()	-- delete current record
 *		isdelrec()	-- delete record by record number
 *
 ************************************************************************
 */

/*
 * isam write routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 *
 * Modification History:
 *   10/18/83  V201  RVH  set treelev = -1 on getrecord()
 */

#include "isdec.c"

/*
 * write new record
 */

iswrite(isfd, record)
int isfd;
char record[];
{
	long recnum = 0;

	if (isenter(isfd, ISOUTPUT) == -1) return(-1);

	wrtrecord(isfd, record, recnum, 0);

	return(isexit());
}

/*
 * write new current record
 */

iswrcurr(isfd, record)
int isfd;
char record[];
{
	long recnum = 0;

	if (isenter(isfd, ISOUTPUT) == -1) return(-1);

	wrtrecord(isfd, record, recnum, 1);

	if (!iserrno) openp->o_flags |= (OCURPOS|OCURREAD);

	return(isexit());
}


/*
 * write out record, update indexes
 */

STATIC int wrtrecord(isfd, record, recnum, currflag)
int isfd;
char record[];
long recnum;
int currflag;
{
	struct item item;
	struct keydesc key;
	register struct item *itemp = &item;
	register struct keydesc *keyp = &key;
	int duperr;
	register int keynum, lastnum;
	int flag = 0;

    do
	{
	recnum = allocrec(DATAREC);	/* allocate data record	*/
	duperr = datacheck(recnum);	/* check for record used*/
	if (duperr == -1)
	    return;
	}
    while (duperr);

	duperr = 0;
	lastnum = ld2(dictp->d_nkeys);

redokeys:
	for (keynum=1; keynum<=lastnum ; keynum++)
	    {					/* go thru each key	*/
	    if (kysearch(keyp, keynum) <= 0)
		break;				/* done ?		*/
	    itmake(record, itemp, keyp);
	    itemp->it_ptr = recnum;
	    if (duperr == 0)
		{
		if (btadditem(itemp, keyp))
		    {
		    lastnum = keynum - 1;	/* duplicate, delete	*/
		    duperr = 1;			/*  items already added	*/
		    goto redokeys;
		    }
		if (currflag && kycompare(keyp, &openp->o_curkey) == 0)
		    itcopy(itemp, &openp->o_curitem, keyp);
		}
	    else
		{
		VOID btdelitem(itemp, keyp);
		}
	    }

	if (iserrno)
	    {
		freerec(recnum, DATAREC);	/* error, free record	*/
	    return;
	    }
	if (datawrite(record, recnum))		/* ok, write out record	*/
	    {
	    VOID datadelete(recnum);
	    duperr = 1;				/* error, remove items	*/
	    goto redokeys;
	    }

	isrecnum = recnum;                      /* return record number */
}

/*
 * rewrite record (by primary key)
 */

isrewrite(isfd, record)

int isfd;
char record[];
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getrecord(record, isfd) != 0)
	    return(isexit());

	rewrecord(isfd, temprecord, record, treeitem.it_ptr, 0);
	return(isexit());
}

/*
 * rewrite current record
 */

isrewcurr(isfd, record)

int isfd;
char record[];
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getcurrent(isfd, 0L) != 0)
	    return(isexit());

	rewrecord(isfd, temprecord, record, openp->o_curitem.it_ptr, 1);
	return(isexit());
}

/*
 * rewrite record by record number
 */

isrewrec(isfd, recnum, record)

int isfd;
long recnum;
char record[];
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getcurrent(isfd, recnum) != 0)
	    return(isexit());

	rewrecord(isfd, temprecord, record, recnum, 0);
	return(isexit());
}

/*
 * rewrite record in isam file
 */

STATIC int rewrecord(isfd, record1, record2, recnum, currflag)

int isfd;
char *record1;
char *record2;
long recnum;
int currflag;
{
	struct item item1, item2;
	struct keydesc key;
	register struct keydesc *keyp = &key;
	register struct item *item1p = &item1;
	register struct item *item2p = &item2;
	register int keynum, lastnum;
	char *temprec;
	int duperr;	/* 0 = rewrite unique indexes		*/
			/* 1 = rewrite duplicate indexes	*/
			/* 2 = change back unique indexes	*/

	duperr = 0;
	lastnum = ld2(dictp->d_nkeys);

redokeys:
	for (keynum=1; keynum<=lastnum || duperr == 0; keynum++)
	    {					/* go thru each key	*/
	    if (keynum > lastnum)
		duperr = keynum = 1;

	    if (kysearch(keyp, keynum) <= 0)
		continue;			/* done ?		*/

	    if (((keyp->k_flags & ISDUPS) != 0) != (duperr == 1))
		continue;
	    
	    itmake(record1, item1p, keyp);
	    itmake(record2, item2p, keyp);
	    if (itcompare(item1p, item2p, keyp, 0) != 0)
		{				/* keys different ?	*/
		item1.it_ptr = recnum;		/* yes, replace them	*/
		item2.it_ptr = recnum;
		if (btadditem(item2p, keyp))
		    {
		    duperr = 2;			/* set error mode	*/
		    lastnum = keynum - 1;
		    temprec = record1;		/* exchange records 1,2	*/
		    record1 = record2;
		    record2 = temprec;
		    goto redokeys;
		    }
		VOID btdelitem(item1p, keyp);
		if (currflag && kycompare(keyp, &openp->o_curkey) == 0)
		    itcopy(item2p, &openp->o_curitem, keyp);
		}
	    }

	if (duperr != 2)
	    {
	    VOID datawrite(record2, recnum);	/* write out new record	*/
	    }
}

/*
 * delete record (by primary key)
 */

isdelete(isfd, record)

int isfd;
char record[];
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getrecord(record, isfd) != 0)
	    return(isexit());

	delrecord(isfd, temprecord, treeitem.it_ptr);
	return(isexit());			/* remove from b-trees	*/
}

/*
 * delete current record
 */

isdelcurr(isfd)

int isfd;
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getcurrent(isfd, 0L) != 0)
	    return(isexit());

	delrecord(isfd, temprecord, openp->o_curitem.it_ptr);
	return(isexit());
}

/*
 * delete record by record number
 */

isdelrec(isfd, recnum)

int isfd;
long recnum;
{
	if (isenter(isfd, ISINOUT) == -1) return(-1);

	if (getcurrent(isfd, recnum) != 0)
	    return(isexit());

	delrecord(isfd, temprecord, recnum);
	return(isexit());
}

/*
 * delete record from isam file
 */

STATIC int delrecord(isfd, record, recnum)

int isfd;
char record[];
long recnum;
{
	struct keydesc key;
	struct item item;
	register struct keydesc *keyp = &key;
	register struct item *itemp = &item;
	register int keynum, lastnum;

	lastnum = ld2(dictp->d_nkeys);

	for (keynum=1; keynum<=lastnum ; keynum++)
	    {					/* go thru each key	*/
	    if (kysearch(keyp, keynum) <= 0)
		break;				/* done ?		*/
	    itmake(record, itemp, keyp);
	    item.it_ptr = recnum;
	    VOID btdelitem(itemp, keyp);
	    }

	VOID datadelete(recnum);
	freerec(recnum, DATAREC);		/* free data record	*/
}

/*
 * get record by primary key
 */

STATIC int getrecord(record, isfd)
char *record;
int isfd;
{
	struct keydesc key;
	struct item item;

	if (kysearch(&key, 1) <= 0)		/* get primary key	*/
	    goto bad;
	if ((key.k_flags & ISDUPS) || key.k_nparts == 0)
	    goto bad;
	itmake(record, &item, &key);		/* make item		*/

	if (isfd == tempisfd)		/* see if already in temprecord */
	    {
	    itmake(temprecord, &treeitem, &key);/* get key of temprecord*/
	    treeitem.it_ptr = tempnum;
	    if (itcompare(&item, &treeitem, &key, 0) == 0)
		goto good;			/* yes, keys match	*/
	    }
	btsearch(&item, &key, 0, 0);
	if (treeflags || treelev < 0)		/* V201 */
	    goto bad;
	treelev = -1;
	if (itcompare(&item, &treeitem, &key, 0) != 0)
	    goto bad;
	if (dataread(temprecord, treeitem.it_ptr) != 0)
	    goto bad;
good:
	isrecnum = treeitem.it_ptr;		/* get record number	*/
	tempisfd = -1;
	return(0);
bad:
	if (!iserrno) iserrno = ENOREC;
	return(-1);
}


/*
 * get current record
 */

STATIC int getcurrent(isfd, recnum)
int isfd;
long recnum;
{
	if (recnum == 0L)
	    {				/* get current record	*/
	    if ((openp->o_flags & (OCURPOS|OCURREAD)) != (OCURPOS|OCURREAD))
		goto bad;
	    isrecnum = openp->o_curitem.it_ptr;
	    }
	else
	    {				/* get specified record	*/
	    if (recnum <= 0 || recnum > ld4(dictp->d_nextdata))
		goto bad;
	    isrecnum = recnum;
	    }

	/* is record already in temprecord ?
	 *  if not read it in
	 */
	if (isfd != tempisfd || isrecnum != tempnum)
	    if (dataread(temprecord, isrecnum) != 0)
		goto bad;

	tempisfd = -1;			/* mark temprecord destroyed	*/
	return(0);
bad:
	if (!iserrno) iserrno = (recnum == 0L ? ENOCURR : ENOREC);
	return(-1);
}

