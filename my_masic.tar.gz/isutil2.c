/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	isutil2.c
 *  Sccsid:	@(#)isutil2.c	5.1.1.1	8/27/87  19:27:38
 *  Description:
 *		Low level utility routines for C-ISAM routines.
 *		(module 1 of 2 - gotten by splitting isutil.c)
 *
 ***************************************************************************
 */

/*
 * utility routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 *
 *  06-07-83  RVH	V104 -- ifdefs for routines not used in kernel
 *  05-11-84		moved isam-specific functions to issupp.c
 *  02-13-85		include just machine.h; change CASTCP, FLOATSIZE,
 *			etc, to vanilla C
 *  08-01-86		split isutil.c into isutil1.c and isutil2.c, for COBOL
 */


#include "machine.h"
#include "isam.h"

#define TRUE	(1)
#define FALSE	(0)

#ifndef ISKERNEL

/*
 * stcat -- concatenate first null terminated string onto second
 */

stcat(src, dst)
    register char *src, *dst;
{
    while (*dst) dst++;
    while (*dst++ = *src++);
}

/*
 * stcmpr -- compare two null terminated strings
 *	     return -1, 0, 1  for  <, ==, > respectively
 */

stcmpr(s1, s2)
    register char *s1, *s2;
{
    for ( ; *s1 == *s2; s1++, s2++)
	if (*s1 == 0) return(0);

    if ((*s1 & BYTEMASK) < (*s2 & BYTEMASK))
	return(-1);
    else return(1);
}

#endif /* ISKERNEL */


/*
 * stcopy -- copy null terminated string
 */

stcopy(src, dst)
    register char *src, *dst;
{
    while (*dst++ = *src++);
}

/*
 * stleng -- calculate null terminated string length
 */

stleng(src)
    register char *src;
{
    register char *dst;

    dst = src;
    while (*dst) dst++;
    return(dst-src);
}

#ifndef NOFLOAT

/*
 * load float number
 */
 
#ifdef ldfloat
#undef ldfloat
#endif /* ldfloat */

double ldfloat(p)
register char *p;
{
	float fval;
	register char *f;
	register int c;

	f = (char *) &fval;
	c = sizeof(float);
	do
	    *f++ = *p++;
	while (--c);
	return(fval);
}

/*
 * store float number
 */

#ifdef stfloat
#undef stfloat
#endif /* stfloat */

stfloat(f,p)
double f;
register char *p;
{
	register char *s;
	register int c;
	float flo = f;

	s = (char *) &flo;
	c = sizeof(float);
	do
	    *p++ = *s++;
	while (--c);
}

/*
 * load double number
 */
 
#ifdef lddbl
#undef lddbl
#endif /* lddbl */

double lddbl(p)
register char *p;
{
	double fval;
	register char *f;
	register int c;

	f = (char *) &fval;
	c = sizeof(double);
	do
	    *f++ = *p++;
	while (--c);
	return(fval);
}

/*
 * store double number
 */

#ifdef stdbl
#undef stdbl
#endif /* stdbl */

stdbl(f,p)
double f;
register char *p;
{
	register char *s;
	register int c;

	s = (char *) &f;
	c = sizeof(double);
	do
	    *p++ = *s++;
	while (--c);
}
#endif /* NOFLOAT */

#ifdef NOLONGMULT
/*
 * long multiply
 */

long longmult(x,y)
long x,y;
{
	long z;

	for (z=0; y!=0 && x!=0; x<<=1, y>>=1)
	    if (y&1) z += x;

	return(z);
}
#endif /* NOLONGMULT */
