/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	isbuild.c
 *  Sccsid:	@(#)isbuild.c	5.1.1.2	1/19/88  15:12:19
 *  Description:
 *		isbuild()	-- build C-ISAM file
 *		isaddindex()	-- add a new index to C-ISAM file
 *		isdelindex()	-- delete an existing index from C-ISAM file
 *		iserase()	-- erase C-ISAM file
 *		isrename()	-- rename C-ISAM file
 *		isremlock()	-- remove old locks from C-ISAM file
 *
 ************************************************************************
 */

/*
 * isam create and delete routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 *
 *  06-07-83 RVH  V104 -- added kernel modifications
 *  10-13-83 RVH  V201 -- prevent deletion of current key
 */

#include "isdec.c"

/*
 * build isam file
 */

isbuild(filename, reclength, keydesc, mode)
    char *filename;		/* V104 NOTE: for kernel, an array of ptrs */
    int reclength;
    register struct keydesc *keydesc;
    register int mode;
{
	register struct buff *bp;
	int isfd;
	char fname[PATHSIZE];

	iserrno = iserrio = 0;

	if (mktemprec(reclength))		/* allocate temprecord	*/
	    goto reterr;

	if ((isfd = allocopen()) < 0)
	    goto reterr;

	openp->o_mode = mode & IOMASK;

	mkidxname(filename, fname);		/* make filename.idx	*/
	if (makefile(fname, IDXMODE) == -1)	/* create index file	*/
	    {
	    iserrio = IO_CREA+IO_IDX;
	    goto reterr;
	    }

	mkdatname(filename, fname);		/* make filename.dat	*/
	if (makefile(fname, DATMODE) == -1)	/* create data file	*/
	    {
	    iserrio = IO_CREA+IO_DAT;
	    goto reterr;
	    }

						/* setup fileid		*/
	filep = openp->o_filep = allocfile(filename, openp->o_mode);
	if (filep == NULL)
	    goto reterr;

	filep->f_idxsize = NODESIZE-1;
	filep->f_datsize = reclength;

	dictp = &filep->f_dict;			/* point to dictionary	*/

	st2(ISMAGIC,	dictp->d_magic);	/* init dictionary	*/
	st1(2,		dictp->d_dummy1+0);
	st1(2,		dictp->d_dummy1+1);
	st1(4,		dictp->d_dummy1+2);
	st1(4,		dictp->d_dummy1+3);
	st2(NODESIZE-1,	dictp->d_idxsize);
	st2(0,		dictp->d_nkeys);
	st1(COMPRESS>>1,dictp->d_cflag);
	st1(2,		dictp->d_dflag);
	st2(reclength,	dictp->d_recsize);
	st4(1L,		dictp->d_uniqid);
	st4(2L,		dictp->d_keysnode);
	st4(2L,		dictp->d_nextnode);

	dictmodify();

	bp = bfgetclr(2L);			/* get keys node block	*/
	bp->bf_used = 6;			/* init used bytes	*/
	bp->bf_level = 0x7E;
	bp->bf_type = 0xFF;
	bfdwrite(bp);

	if (kyadd(keydesc) != 0)
	    iserrno = EBADKEY;

	kycopy(keydesc, &openp->o_curkey);	/* make it current key	*/

	if (iserrno == 0)
	    {
	    VOID isexit();
	    return (isfd);
	    }

reterr:
	return(-1);				/* return error	code	*/
}
