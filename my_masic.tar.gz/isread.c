/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	isread.c
 *  Sccsid:	@(#)isread.c	5.1.1.2	3/25/88  16:43:00
 *  Description:
 *		isread()	-- read record from C-ISAM file
 *		isstart()	-- set index and position in C-ISAM file
 *
 ************************************************************************
 */

/*
 * isam read routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 */

#include "isdec.c"

/*
 * position current pointer and read record
 */

isread(isfd, record, mode)
int isfd;
char record[];
register int mode;
{
	register struct keydesc *curkey;
	register struct item *curitem;
	register int lockmode, dir, waited = 0;

retry:
	if (isenter(isfd, ISINPUT+LOCKSHARE+ISREAD) == -1) return(-1);

	lockmode = mode & LOCKMASK;		/* locking mode		*/
	switch(lockmode)
	    {
	    case 0:
		if (openp->o_mode & ISAUTOLOCK)
		    lockmode = ISLOCK;
		break;
	    case ISWAIT:
		if (openp->o_mode & ISAUTOLOCK)
		    lockmode += ISLOCK;
		break;
	    case ISLOCK:
	    case ISLCKW:
		break;
	    default:
		iserrno = EBADARG;
		return(isexit());
	    }

	curkey  = &openp->o_curkey;
	curitem = &openp->o_curitem;

	mode &= IOMASK;				/* sequence mode	*/
	switch(mode)
	    {
	    case ISFIRST:
	    case ISLAST:
	    case ISEQUAL:
	    case ISGREAT:
	    case ISGTEQ:
		kposition(record, 0, mode);	/* position first	*/
		break;

	    case ISNEXT:
	    case ISPREV:
	    case ISCURR:
		if (curkey->k_nparts == 0)	/* physical order ?	*/
		    {
		    treeflags = treelev = 0;
		    treeitem.it_ptr = curitem->it_ptr;
		    break;
		    }
		if (btcurrent() != 0)		/* setup current tree	*/
		    goto bad;
		break;

	    default:
		iserrno = EBADARG;
	    }

	if (iserrno) return(isexit());		/* any errors so far ?	*/

	if (mode == ISPREV || mode == ISLAST)
	    {					/* process previous	*/
	    dir = ISPREV;
	    if (mode == ISLAST || waited == 0)
		btmove(curkey, ISPREV);
	    }
	else dir = ISNEXT;

	if (mode == ISNEXT &&
	    ((openp->o_flags & OCURREAD) || (treeflags & BEGFILE)))
	    {					/* process next		*/
	    btmove(curkey, ISNEXT);
	    }

	openp->o_flags &= ~OCURREAD;		/* turn off curr read	*/

	if (treeflags & (BEGFILE|ENDFILE))
	    iserrno = EENDFILE;
	else
	    {
	    while (dataread(record, treeitem.it_ptr) != 0)
		{				/* find good record	*/
		if (mode == ISCURR) goto bad;
		if (mode == ISEQUAL) goto bad1;
		if (treeflags) goto bad3;
		btmove(curkey, dir);
		}

	    itcopy(&treeitem, curitem, curkey);	/* new current item	*/

			/* check next key for duplicate - cobol necessity */
	    if (curkey->k_flags & ISDUPS)
		{
		btdups(curkey, dir);		/* check next key for dup */
		}

	    openp->o_flags |= OCURREAD;		/* read current record	*/
	    isrecnum = treeitem.it_ptr;		/* return record number	*/
	    if (lockmode & ISLOCK)
		{				/* save locked records	*/
#ifdef ISKERNEL
		tempisfd = -2;			/* special flag	to user	*/
		tempnum  = filep->f_datsize;	/* process, copy record	*/
#else
		bycopy(record, temprecord, filep->f_datsize);
		tempisfd = isfd;
		tempnum  = isrecnum;
#endif  /* ISKERNEL */
		}
	    }

	return(isexit());

bad:	if (!iserrno) iserrno = ENOCURR;
bad1:	if (!iserrno) iserrno = ENOREC;
bad2:	if (!iserrno) iserrno = ELOCKED;
bad3:	if (!iserrno) iserrno = EENDFILE;
	return(isexit());
}


/*
 * initialize tree position
 */

STATIC int kposition(record, keylen, mode)

char record[];
int keylen;
int mode;
{
	struct item item;
	register struct keydesc *keydesc;

	treeflags = treelev = 0;
	keydesc = &openp->o_curkey;

	switch(mode)
	    {
	    case ISFIRST:
	    case ISLAST:
		if (keydesc->k_nparts == 0)	/* physical read ?	*/
		    {
		    if (mode == ISLAST) dictread();
		    treeitem.it_ptr =
			(mode == ISFIRST) ? 1L :	/* first record	*/
			 dictp->d_nextdata + 1L;	/* last record+1*/
		    }
		else btposition(keydesc, mode);
		break;
	    case ISEQUAL:
	    case ISGREAT:
	    case ISGTEQ:
		if (keydesc->k_nparts == 0)
		    {
		    treeitem.it_ptr = isrecnum + (mode == ISGREAT);
		    if (treeitem.it_ptr > dictp->d_nextdata)
			{
			dictread();		/* in case of old info	*/
			if (treeitem.it_ptr > dictp->d_nextdata)
			    iserrno = EENDFILE;
			}
		    break;
		    }
		itmake(record, &item, keydesc);
		btsearch(&item, keydesc, keylen, (mode == ISGREAT));
		if (treeflags & (BEGFILE|ENDFILE))
		    iserrno = ENOREC;
		if (mode == ISEQUAL &&
			itcompare(&item, &treeitem, keydesc, keylen) != 0)
		    iserrno = ENOREC;
		break;
	    default:
		iserrno = EBADARG;
		break;
	    }

	openp->o_flags &= ~(OCURPOS|OCURREAD);
	if (iserrno)
	    return;
	itcopy(&treeitem, &openp->o_curitem, keydesc);
					/* set new current item	*/
	openp->o_flags |= OCURPOS;
	isrecnum = treeitem.it_ptr;	/* return record number	*/
}
