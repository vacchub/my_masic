/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	isdef.c
 *  Sccsid:	@(#)isdef.c	5.1.1.1	8/27/87  19:25:18
 *  Description:
 *		Global variable definitions for C-ISAM routines.
 *
 ************************************************************************
 */

#include "btree.h"

char *isversnumber = "C-ISAM Version 3.3.2";
char *iscopyright  = COPYRT;
//extern char snnumber[];
//extern short demoversion;
//char *isserial = snnumber;
int issingleuser   = 0;

#ifdef lint
STATIC int _VOID_ = 0;
#endif

extern int errno;
int  iserrno;
int  iserrio;
long isrecnum;
char isstat1;
char isstat2;
int  tempisfd = -1;
long tempnum  = -1;

STATIC struct item treeitem;
STATIC short treelev;
STATIC short treeleaf;
STATIC short treeflags;
STATIC struct ifile *filep;
STATIC struct iopen *openp;
STATIC struct dict *dictp;

STATIC struct reclist *rlfree = NULL;
STATIC short nfiles = NFILES;
STATIC struct ifile *files[NFILES];
STATIC short nopens = NOPENS;
STATIC struct iopen *opens[NOPENS];

STATIC short nbuffs = NBUFS;
STATIC struct buff avbuffs;

STATIC struct buff *buffs;
STATIC char *buffers;

#ifdef DRVRLOCK
STATIC short lkfd = -1;
STATIC struct liocb liocb;
STATIC struct lock  locks[NLOCKS];
#endif

STATIC char *temprecord;
STATIC short temprsize;

