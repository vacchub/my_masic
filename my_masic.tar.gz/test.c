#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "isam.h"

#define MAX_NUM 400
char array[MAX_NUM];

#define TEST_NUM 200

struct test {
    unsigned int key;
    int value;
};
struct keydesc test_k[] = {
    { ISNODUPS, 1,
        {{ 0, 4, LONGTYPE }}},
};

int main(int argc, char *argv[])
{
	struct test test;
	int isfd, isrc, ismd, ii, rnum;

	srand((unsigned)time(NULL));
	memset(array, '0', sizeof(array));
	system("rm -f ./TEST.*");

	isfd = isbuild("./TEST", sizeof(struct test), &test_k[0], ISINOUT+ISMANULOCK);
    if (isfd < 0) {
        printf ("Error creating database: %d\n", iserrno);
        return 0;
    }

#if 0
	memset(&test, 0x00, sizeof(struct test));
	test.key = 2;
	test.value = 2;
	isrc = iswrite(isfd, (char *)&test);
	if (isrc != 0)
	{
		printf("iswrite error\n");
		return 0;
	}

	isrc = isread(isfd, (char *)&test, ISFIRST);

return 0;
#else
	for (ii = 0; ii < TEST_NUM; ii++)
	{
		while (1)
		{
			rnum = rand() % MAX_NUM;
			if (rnum == 0)
				continue;
			if (array[rnum] == '0')
			{
				array[rnum] = '1';
				break;
			}
		}
rnum = ii+10;
		memset(&test, 0x00, sizeof(struct test));
		test.key = rnum;
		test.value = rnum;
		isrc = iswrite(isfd, (char *)&test);
		if (isrc != 0)
		{
			printf("iswrite error\n");
			return 0;
		}
	}

	isrc = isread(isfd, (char *)&test, ISFIRST);
#endif

	memset(&test, 0x00, sizeof(test));
	test.key = 1;
	for (ii = 0, ismd = ISGTEQ; ; ismd = ISGREAT, ii++)
	{
		isrc = isread(isfd, (char *)&test, ismd);
		if (isrc != 0)
			break;

		printf("%d key[%d] value[%d]\n", ii, test.key, test.value);
	}

#if 0
	memset(&test, 0x00, sizeof(struct test));
    test.key = atoi(argv[1]);
    isdelete(isfd, (char *)&test);
#endif

	isclose(isfd);

	return 0;
}


