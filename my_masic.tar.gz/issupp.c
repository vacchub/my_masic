/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	issupp.c
 *  Sccsid:	@(#)issupp.c	5.1.1.3	11/9/88  17:22:12
 *  Description:
 *		Support routines for C-ISAM routines.
 *
 ************************************************************************
 */

/*
 * support routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 *
 *  06-07-83  RVH	V104 -- added kernel modifications
 *  08-24-83  RVH	V105 -- dynamic memory allocation
 *  03-02-84  RVH	V202 -- close files on exec()
 *  05-11-84  DKE	moved isam-specific functions here from isutil.c
 */

#include "isdec.c"

#ifdef ISPCLOSE
int ismaxfds = 0;
static int isopenfds = 0;
#endif /* ISPCLOSE */
/*
 * allocate an open file entry
 * returns isfd
 */

STATIC int allocopen()
{
	register int isfd;

	for (isfd=0; isfd<nopens; isfd++)
	    {
	    openp = opens[isfd];
	    if (openp == NULL)			/* V105	*/
		{
		opens[isfd] = openp =
			(struct iopen *) malloc(sizeof(struct iopen));
		if (openp == NULL)
		    goto bad;
		openp->o_flags = 0;
		}
	    if (openp->o_flags == 0)		/* find free open	*/
		{
		byfill(CASTCP openp, sizeof(struct iopen), 0);
		openp->o_procid = getpid();
		openp->o_userid = getuid();
		openp->o_flags = OBUSY;
		return(isfd);
		}
	    }
	iserrno = ETOOMANY;
	return(-1);
bad:
	iserrno = EBADMEM;
	return(-1);
}

STATIC int freeopen(op)
register struct iopen *op;
{
	if (op->o_filep != NULL)
	    freefile(op->o_filep);		/* free file struct	*/
	op->o_flags = 0;
}


/*
 * allocate a isam file block
 */

STATIC struct ifile *allocfile(filename, mode)
char *filename;		/* V104 -- NOTE: for kernel this is array of ptrs */
register int mode;
{
	register struct ifile *fp, *zfp;
	register int i;
	dev_t filedev;
	ino_t fileino;
#ifdef ISVOPEN
 	int secondtry;
#endif /* ISVOPEN */
	char fname[PATHSIZE];

	secondtry = 0;

	mkidxname(filename, fname);

	for (i=0; i<nfiles && (fp = files[i]) != NULL; i++)
		if (fp->f_ucount >= 0 &&  stcmpr(filename,fp->f_fname) == 0 )
			goto found;	/* found file name */

	if (getfileid(fname, &filedev, &fileino))
	    return(NULL);			/* get file identifier	*/

retryfind:
	zfp = NULL;

	for (i=0; i<nfiles; i++)
	    {
	    fp = files[i];			/* search for existing	*/
	    if (fp == NULL && zfp == NULL)	/* dynamic allocation	*/
		{
		files[i] = fp =
			(struct ifile *) malloc(sizeof(struct ifile));
		if (fp == NULL)
		    {
		    iserrno = EBADMEM;
		    return(NULL);
		    }
		fp->f_ucount = -1;
		}
	    if (fp && fp->f_ucount >= 0 && fp->f_inum == fileino &&
		    fp->f_dev == filedev)
		goto found;			/* match fileid		*/
	    if (zfp == NULL && fp->f_ucount  == -1)
		zfp = fp;			/* save empty one	*/
	    }

	if (zfp == NULL)
	    {
#ifdef ISPCLOSE
	    if ( !secondtry )
		{
		vclose();
		secondtry = 1;
		goto retryfind;
		}
#endif /* ISPCLOSE */
	    iserrno = ETOOMANY;
	    return(NULL);
	    }

	fp = zfp;				/* use empty one	*/
	byfill(CASTCP fp, sizeof(struct ifile), 0);
	fp->f_ucount = -1;

	i = RWMODE;
#ifdef ISVOPEN
	secondtry = 0;
#endif /* ISVOPEN */
idxagain:
	usrmemory();
	if ((fp->f_idxfd = open(fname, i)) == OPENERR)
	    {
#ifdef ISVOPEN
	    if (errno == EMFILE && !secondtry) 
		{
		vclose();
		secondtry = 1;
		goto idxagain;
		}
#endif /* ISVOPEN */
	    iserrno = errno;
	    iserrio = IO_OPEN+IO_IDX;
	    return(NULL);
	    }
	CLOSEXEC(fp->f_idxfd);		/* V202 - close file on exec()	*/
#ifdef ISPCLOSE
	isopenfds++;
#endif /* ISPCLOSE */

	mkdatname(filename, fname);
	i = RWMODE;
#ifdef ISVOPEN
	secondtry = 0;
#endif /* ISVOPEN */
datagain:
	usrmemory();
	if ((fp->f_datfd = open(fname, i)) == OPENERR)
	    {
	    if (errno == EACCES && i == RWMODE && mode == ISINPUT)
		{
		i = RMODE;
		goto datagain;
		}
#ifdef ISVOPEN
	    if (errno == EMFILE && !secondtry) 
		{
		vclose();
		secondtry = 1;
		goto datagain;
		}
#endif /* ISVOPEN */
	    iserrno = errno;
	    iserrio = IO_OPEN+IO_DAT;
	    VOID close(fp->f_idxfd);
	    return(NULL);
	    }
#ifdef ISVOPEN
	stcopy(filename,fp->f_fname);
	fp->f_omode = i;
#endif /* ISVOPEN */
	CLOSEXEC(fp->f_datfd);		/* V202 - close file on exec()	*/

	fp->f_dev  = filedev;
	fp->f_inum = fileino;
	fp->f_ucount = 0;

found:
	fp->f_ucount++;
	return(fp);
}

STATIC int freefile(fp)
register struct ifile *fp;
{
	if (--fp->f_ucount > 0) return;		/* still in use		*/
#ifdef ISPCLOSE
	if ( isopenfds < ismaxfds && fp->f_ucount == 0)
			return;
	isopenfds--;
#endif /* ISPCLOSE */

#ifndef SHMBUFF
	bfignor(fp);
#endif  /* SHMBUFF */
	if (fp->f_flags & FAUDOPEN)
	    VOID close(fp->f_audfd);
	fp->f_ucount = -1;
	fp->f_flags = 0;			/* deallocate table	*/
	fp->f_dev   = -1;
	fp->f_inum  = -1;
	VOID close(fp->f_idxfd);
	VOID close(fp->f_datfd);
}

/*
 * allocate index or data record
 */

STATIC long allocrec(flag)
int flag;
{
	register struct buff *bp;
	register char *freep, *nextp;
	long node, node2;

	if (flag == INDXREC)			/* INDXREC or DATAREC	*/
	    {
	    freep = dictp->d_freenode;
	    nextp = dictp->d_nextnode;
	    }
	else
	    {
	    freep = dictp->d_freedata;
	    nextp = dictp->d_nextdata;
	    }

next:
	node = ld4(freep);
	if (node == 0)				/* no free nodes	*/
	    {
extend:	    node = ld4(nextp) + 1L;
	    st4(node, nextp);			/* extend file		*/
	    dictmodify();
	    }
	else
	    {
	    bp = bfread(node);			/* get free list	*/
	    if (bp == NULL) goto extend;
	    bp->bf_used -= 4;			/* get next free node	*/
	    node2 = ld4(bp->bf_un.bf_addr+bp->bf_used);
	    if (bp->bf_used <= 2)
		{
		st4(node2, freep);
		dictmodify();
		if (flag != INDXREC)
		    {
		    bfrelease(bp);
		    freerec(node, INDXREC);	/* free index record	*/
		    goto next;
		    }
		}
	    else
		{
		node = node2;
		}
	    bfdwrite(bp);
	    }
	return(node);
}

/*
 * free index or data record
 */

STATIC int freerec(node, flag)
long node;
int flag;
{
	register struct buff *bp;
	register char *freep, *nextp;
	long fnode, node2;

	if (flag == INDXREC)			/* INDXREC or DATAREC	*/
	    {
	    freep = dictp->d_freenode;
	    nextp = dictp->d_nextnode;
	    }
	else
	    {
	    freep = dictp->d_freedata;
	    nextp = dictp->d_nextdata;
	    }

	if (node == ld4(nextp))			/* freeing last record ?*/
	    {
	    node--;
	    st4(node, nextp);			/* yes, just shrink file*/
	    dictmodify();
	    return;
	    }

	fnode = ld4(freep);
	if (fnode == 0)				/* no free list ?	*/
	    {
newfree:
	    if (flag != INDXREC)
		node2 = allocrec(INDXREC);
	    else node2 = node;

	    st4(node2, freep);			/* create free list	*/
	    dictmodify();
	    bp = bfgetclr(node2);
	    bp->bf_used = 6;
	    bp->bf_level = 0x7F;
	    bp->bf_type = (flag == INDXREC)? 0xFE: 0xFF;
	    st4(fnode, bp->bf_un.bf_free->fn_next);
	    if (flag != INDXREC)
		{
            st4(node, bp->bf_un.bf_addr+6);	/* store free node	*/
			bp->bf_used = 10;
		}
	    bfdwrite(bp);
	    }
	else
	    {
	    bp = bfread(fnode);			/* get free list	*/
	    if (bp == NULL) return;
	    if (bp->bf_used+4 < filep->f_idxsize-2)
		{
	       	st4(node, bp->bf_un.bf_addr+bp->bf_used);
			bp->bf_used += 4;
		}
	    else
		{
		bfrelease(bp);
		goto newfree;
		}
	    bfdwrite(bp);
	    }
}

/*
 * make a new file
 */

STATIC int makefile(fname, mode)
register char *fname;
int mode;
{
	register int fd;
#ifdef ISVOPEN
 	int secondtry =0;
tryagain:
#endif /* ISVOPEN */

	errno = EEXIST;
	if ((fd = open(fname, RWMODE)) != -1 || errno != ENOENT)
#ifdef ISVOPEN
	    if (errno == EMFILE && !secondtry) 
		{
		vclose();
		secondtry = 1;
		goto tryagain;
		}
	    else
#endif /* ISVOPEN */
	    goto bad;				/* file already exist ?	*/

#ifdef ISVOPEN
 	secondtry =0;
creagain:
#endif /* ISVOPEN */
	if ((fd = creat(fname, mode)) == -1)
#ifdef ISVOPEN
	    if (errno == EMFILE && !secondtry) 
		{
		vclose();
		secondtry = 1;
		goto creagain;
		}
	    else
#endif /* ISVOPEN */
	    goto bad;				/* create file		*/

	VOID close(fd);
	return(0);
bad:
	iserrno = errno;			/* system error		*/
	if (fd != -1) VOID close(fd);
	return(-1);
}


/*
 * return unique file identifier
 */

STATIC int getfileid(fname, devp, inump)
char *fname;
dev_t *devp;
ino_t *inump;
{
	struct stat st;

	if (stat(fname, &st))		/* get device & inode num */
	    {
	    iserrno = errno;
	    return(-1);
	    }
	*devp  = st.st_dev;
	*inump = st.st_ino;
	return(0);
}



/*
 * read a data record into "record"
 */

dataread(record, recnum)
    char *record;
    long recnum;
{
    return dataxfer(0, record, recnum);
}

/*
 * write a data record from "record"
 */

datawrite(record, recnum)
    char *record;
    long recnum;
{
    return dataxfer(1, record, recnum);
}

/*
 * delete a data record
 */

datadelete(recnum)
    long recnum;
{
    return dataxfer(2, temprecord, recnum);
}

/*
 * check a data record
 */

datacheck(recnum)
    long recnum;
{
    return dataxfer(3, temprecord, recnum);
}


/*
 * tranfer data record to/from cached buffers
 */

dataxfer(flag, record, recnum)
    int flag;		/* 0=read, 1=write, 2=delete, 3=check */
    char *record;
    long recnum;
{
    register char *ptr;
    register int cnt, n, datsize, offset;
    register struct buff *bp;
    register long daddr;
    register int cc = 0;

    datsize = filep->f_datsize + 1;

    daddr = (recnum-1) * datsize;
    if (flag == 3)			/* datacheck */
	{
	daddr += datsize - 1;		/* point to terminating byte	*/
	datsize = 1;
	}
    offset = daddr & (NODESIZE-1);
    daddr = (daddr / NODESIZE) + DATABUF;
    while (datsize)
	{
	/* cnt = # bytes to be transferred
	 */
	cnt = NODESIZE - offset;
	if (cnt > datsize) cnt = datsize;
	/*
	 * get the buffer -- no need to read if whole
	 *  block will be overwritten
	 */
	if (flag == 0 || flag == 3 || cnt < NODESIZE)
	     bp = bfread(daddr);
	else bp = bfgetblk(daddr);
	if (bp == NULL)
	    {
	    cc = -1;
	    break;
	    }
	/*
	 * do actual transfers
	 */
	ptr = bp->bf_un.bf_addr+offset;
	switch (flag)
	    {
	    case 0:			/* dataread	*/
		    n = cnt;
		    if ( cnt == datsize )
			{
			n--;
			cc = *(ptr+n) == '\n' ? 0  : -1;
		    	}
		    bycopy(ptr, record, n);
		    bfrelease(bp);
		    break;
	    case 1:			/* datawrite	*/
		    n = cnt;
		    if ( cnt == datsize )
			{
			n--;
			*(ptr+n) = '\n';
		    	}
		    bycopy(record, ptr, n);
		    cc = bfwrite(bp);
		    break;
	    case 2:			/* datadelete	*/
		    byfill(ptr, cnt, 0);
		    bfdwrite(bp);
		    break;
	    case 3:			/* datacheck	*/
		    cc = (*ptr == '\n');
		    bfrelease(bp);
		    break;
	    }
	record += cnt;
	datsize -= cnt;
	offset = 0;
	daddr++;
	}
ret:
    return(cc);
}



/*
 * fatal system error
 */

static char fatalmsg[] =  "\r\nFatal system error: ";

#ifdef PCDOS
#define wrterr(x)	write(2, x, stleng(x))
#endif

#ifdef MPM86
#define wrterr(x)	printf(x)
#endif

#ifndef wrterr
#define wrterr(x)	VOID write(2, x, stleng(x))
#endif

STATIC int error(msg)
char *msg;
{
	wrterr(fatalmsg);
	wrterr(msg);
	wrterr("\r\n");
	abort();
}



/* define for number of reclist entries to allocate at a time */
#define RLALLOC	32

/*
 * record list management routines
 *
 *  rlinsert(list, recnum)	insert record number into list
 *
 *	returns:
 *		-1 error - out of memory
 *		0  OK
 */

rlinsert(list, recnum)
    struct reclist **list;
    register long recnum;
{
    register struct reclist *rlp;

    /* if none free allocate another chunk of structures
     */
    if (rlfree == NULL)
	{
	rlfree = (struct reclist *) malloc(RLALLOC*sizeof(struct reclist));
	if (rlfree == NULL) return -1;
	for (rlp = rlfree; rlp < rlfree+RLALLOC-1; rlp++)
	    rlp->rl_next = rlp+1;
	rlp->rl_next = NULL;
	}
    /* pull off first in list
     */
    rlp = rlfree;
    rlfree = rlp->rl_next;
    rlp->rl_next = *list;
    rlp->rl_recnum = recnum;
    *list = rlp;
    return 0;
}


/*
 *  rldelete(list, recnum)	delete record number from list
 *
 *	returns:
 *		1  record number found and deleted
 *		0  record number not found
 */

rldelete(list, recnum)
    struct reclist **list;
    register long recnum;
{
    register struct reclist *rlp, *last;

    last = NULL;
    for (rlp = *list; rlp; rlp = rlp->rl_next)
	{
	if (rlp->rl_recnum == recnum)
	    {
	    if (last == NULL)
		*list = rlp->rl_next;
	    else last->rl_next = rlp->rl_next;
	    rlp->rl_next = rlfree;
	    rlfree = rlp;
	    return 1;
	    }
	last = rlp;
	}
    return 0;
}


/*
 *  rlcheck(list, recnum)	check for record number int list
 *
 *	returns:
 *		1  record number found
 *		0  record number not found
 */

rlcheck(list, recnum)
    struct reclist **list;
    register long recnum;
{
    register struct reclist *rlp;

    for (rlp = *list; rlp; rlp = rlp->rl_next)
	{
	if (rlp->rl_recnum == recnum)
	    return 1;
	}
    return 0;
}

/*
 * filename handling routines
 *   converts C-ISAM filenames to operating system names
 */

/*
 * check for legal file name
 *	checks length whole path < PATHSIZE-5   --  ".idx" + NULL
 *	checks length last part <= 10 and > 0   --  14 - 4
 *   returns:
 *	 0 => OK file name
 *      -1 => bad file name (iserrno == EFNAME)
 */

STATIC int ckfilname(name)
char *name;
{
	register char *fp, *last;

#ifdef PCDOS
	for (fp = name; *fp; fp++)
	    if (*fp == '<' || *fp == '>' || *fp == '|')  /* don't chk '.' */
		goto bad;

	last = (name[1] == ':') ? name+2 : name;
	for (fp = last; *fp != 0; fp++)
	    if (*fp == '/' || *fp == '\\') last = fp+1;
	if (*last == 0 || stleng(last) > 8 ||
	    stleng(name) >= PATHSIZE -5)
	    goto bad;
#else
	for (fp = last = name; *fp; )
	    if (*fp++ == '/') last = fp;

	if (stleng(name) >= PATHSIZE-5 || stleng(last) > 10 || *last == 0)
	    goto bad;
#endif /* PCDOS */
	return(0);

bad:	iserrno = EFNAME;
	return(-1);
}


/*
 * make index file name
 */

STATIC int mkidxname(iname, oname)
register char *iname, *oname;
{
	stcopy(iname, oname);
	stcat(IDXNAME, oname);
}

/*
 * make data file name
 */

STATIC int mkdatname(iname, oname)
register char *iname, *oname;
{
	stcopy(iname, oname);
	stcat(DATNAME, oname);
}


#ifdef ISVOPEN
#ifdef ISPCLOSE
isvclose(n)
int n;
{
	ismaxfds = n;
	if ( isopenfds > ismaxfds )
		vclose();
}

#endif /* ISPCLOSE */
vclose()
{
	register struct ifile *fp, *lfp;
	register int i;
#ifdef ISPCLOSE
	int cnt;

	do
	{
	cnt = 0;
#endif /* ISPCLOSE */

	lfp = NULL;
	for (i=0; i<nfiles; i++)
	    {
	    fp = files[i];		/* search for file to close	*/
	    if ( fp != NULL && fp->f_ucount != -1 )
		{
#ifdef ISPCLOSE
		cnt++;
		if (fp->f_ucount == 0 ) 
		    {
		    if (lfp == NULL ||  fp->f_vrefcnt < lfp->f_vrefcnt 
			    ||  lfp->f_ucount != 0 )
			lfp = fp;
		    }
	        else 
#endif /* ISPCLOSE */
	        if ( fp->f_datfd >= 0 )
		    {
		    if ((fp->f_flags & FLOCKS) == 0)
			if (lfp == NULL ||
				( fp->f_vrefcnt < lfp->f_vrefcnt
					&& lfp->f_ucount > 0 ) )
			    lfp = fp;
		    }
		}
	    }
	if ( lfp )
#ifdef ISPCLOSE
	    if ( lfp->f_ucount == 0 )
		freefile(lfp);
	    else
#endif /* ISPCLOSE */
		{
#ifndef SHMBUFF
		bfflush(lfp);
#endif  /* SHMBUFF */
		close(lfp->f_datfd);
		lfp->f_datfd = -1;
		if (filep->f_flags & FAUDOPEN)
		    {
	   	    close(lfp->f_audfd);
		    lfp->f_audfd = -1;
		    filep->f_flags &= ~FAUDOPEN;
		    }
		}
#ifdef ISPCLOSE
	} while ( cnt >= ismaxfds && lfp );
	isopenfds = cnt;
#endif /* ISPCLOSE */
}
#endif /* ISVOPEN */

