/***************************************************************************
 *
 *			   INFORMIX SOFTWARE, INC.
 *
 *			      PROPRIETARY DATA
 *
 *	THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF 
 *	INFORMIX SOFTWARE, INC.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN
 *	CONFIDENCE.  INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR 
 *	DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT 
 *	SIGNED BY AN OFFICER OF INFORMIX SOFTWARE, INC.
 *
 *	THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *	SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE. 
 *	UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 *
 *  Title:	isopen.c
 *  Sccsid:	@(#)isopen.c	5.1.1.2	9/25/87  14:51:40
 *  Description:
 *		isopen()	-- open a C-ISAM file
 *		isclose()	-- close a C-ISAM file
 *		isrelease()	-- release locks on C-ISAM file
 *		iscleanup()	-- close all C-ISAM files
 *		isuniqueid()	-- get next unique identifier
 *		issetunique()	-- set next unique identifier
 *		isindexinfo()	-- get index information
 *		iststindex()	-- test for existence of index
 *
 ************************************************************************
 */

/*
 * isam open and close routines
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	November 4, 1981
 *
 *  06-07-83  RVH	V104 -- added kernel modifications
 */

#include "isdec.c"

#ifdef	PCDOS
#include <fcntl.h>
#endif

extern struct filelist *openfile;

/*
 * open isam file
 */
 
isopen(filename, mode)
char *filename;		/* V104 - NOTE: for kernel this is array of ptrs */
register int mode;
{
	register int lockmode;
	register int isfd;
	register struct filelist *next;
	struct keydesc key;
	char *buff;

	if ((isfd = allocopen()) < 0)		/* allocate open struct	*/
	    goto reterr;

	openp->o_tmpfree = NULL;		/* init temp free list	*/

						/* allocate file struct	*/
	filep = openp->o_filep = allocfile(filename, openp->o_mode);
	if (filep == NULL)
	    goto openerr;

	if (isenter(isfd, openp->o_mode))
	    goto openerr;

	openp->o_mode += lockmode;		/* add in lock mode now	*/

	filep->f_idxsize = ld2(dictp->d_idxsize);
	filep->f_datsize = ld2(dictp->d_recsize);
	if (mktemprec(filep->f_datsize))
	    goto opener2;

	kposition(temprecord, 0, ISFIRST);

	if (iserrno == 0)
	    {
	    VOID isexit();
	    return(isfd);			/* return is file desc	*/
	    }

opener2:
	VOID isexit();
openerr:
	freeopen(openp);
reterr:
	isstat1 = '9';
	return(-1);				/* return error	code	*/
}


/*
 * close isam file
 */

isclose(isfd)
int isfd;
{
	register int cc = 0;
	register struct filelist *next;

	if (isenter(isfd, -1) == -1)
	    return(-1);

	if (tempisfd == isfd) tempisfd = -1;

	cc = isexit();
	bfflush(filep);
	freeopen(openp);
	return(cc);
}

/*
 * enter into isam routine
 */

STATIC int isenter(isfd, mode)
register int isfd;
register int mode;
{
	register long ver;
#ifdef ISVOPEN
	char filename[PATHSIZE+4];
	static short vorefcnt = 0;
#endif ISVOPEN

	iserrno = iserrio = 0;			/* clear error codes	*/
	isstat1 = isstat2 = '0';
	mode++;
	if (isfd < 0 || isfd >= nopens)
	    goto starterr;
	filep = openp->o_filep;
	dictp = &filep->f_dict;
	filep->f_flags &= ~FMODF;
	openp->o_flags &= ~ODUPL;

	if ((mode & (openp->o_mode+1) & 3) != (mode & 3))
	    goto starterr;

	treelev = openp->o_trlev;		/* restore tree globals	*/
	treeleaf = openp->o_trleaf;
	treeflags = openp->o_trflags;

	ver = ld4(dictp->d_transaction);
	if (openp->o_version != ver)		/* versions match ?	*/
	    {
	    openp->o_version = ver;		/* no, ignor all saved	*/
	    if (filep->f_version != ver)
		{
		filep->f_version = ver;
		bfignor(filep);			/* ignor buffers	*/
		}
	    treelev = -1;
	    }
	if (treelev >= 0)			/* init treeitem	*/
	    itcopy(&openp->o_curitem, &treeitem, &openp->o_curkey);

#ifdef ISVOPEN
	/* reopen dat file if needed */
	if ( filep->f_datfd == -1 )
	    {
	    mkdatname(filep->f_fname,filename);
	    if ((filep->f_datfd = open(filename, filep->f_omode))<0
			&& errno == EMFILE)
		{
		vclose();
		filep->f_datfd = open(filename, filep->f_omode);
		}
	    if (filep->f_datfd < 0)
		{
		iserrno = errno;	
		goto reterr;
		}
	    filep->f_vrefcnt = ++vorefcnt;
	    }	
	else
	    if ( filep->f_vrefcnt != vorefcnt )
			filep->f_vrefcnt = ++vorefcnt;
#endif ISVOPEN

	return(0);

starterr:
	iserrno = ENOTOPEN;			/* file not open	*/
reterr:
	isstat1 = '9';
	return(-1);
}

/*
 * exit from isam routine
 */

STATIC int isexit()
{
	openp->o_trlev = treelev;		/* save tree globals	*/
	openp->o_trleaf = treeleaf;
	openp->o_trflags = treeflags;

	if (filep->f_flags & FMODF)		/* file modified ?	*/
	    {					/* yes			*/
	    filep->f_flags &= ~FMODF;		/* clear modified bit	*/
	    openp->o_version = ++filep->f_version;
	    st4(openp->o_version, dictp->d_transaction);
						/* inc version number	*/
	    dictmodify();

	    if (! (openp->o_mode & ISEXCLLOCK))	/* if not exclusive	*/
		bfflush(filep);			/* flush node buffers	*/
	    }

	if (filep->f_flags & FDICTMOD)
	    dictwrite();			/* release dict buffer	*/

	return(iserrno? -1: 0);
}

/*
 * dictionary management routines
 *  operates on dictionary node of index file
 *
 * Relational Database Systems, Inc.
 * Roy Harrington	March 22, 1984
 *
 */

/*
 * read dictionary info into file table
 */

#define DICTSIZE (sizeof(struct dict))
#define DICTADDR ((char*) dictp)

dictread()
{
	sysmemory();
	if (lseek(filep->f_idxfd, 0L, 0) != 0L)
	    {
	    iserrno = errno;
	    iserrio = IO_SEEK+IO_IDX;
	    return(-1);
	    }
	if (read(filep->f_idxfd, DICTADDR, DICTSIZE) != DICTSIZE)
	    {
	    iserrno = errno;
	    iserrio = IO_READ+IO_IDX;
	    return(-1);
	    }
	return(0);
}

/*
 * write dictionary info out to file
 */

dictwrite()
{
	int     c;

	sysmemory();
	if (lseek(filep->f_idxfd, 0L, 0) != 0L)
	    {
	    iserrno = errno;
	    iserrio = IO_SEEK+IO_IDX;
	    return(-1);
	    }
	if ((c=write(filep->f_idxfd, DICTADDR, DICTSIZE)) != DICTSIZE)
	    {
//	    printf("gave %d error %d\n",c,errno);
	    iserrno = errno;
	    iserrio = IO_WRIT+IO_IDX;
	    return(-1);
	    }
	filep->f_flags &= ~FDICTMOD;	/* clear modified bit	*/
//	printf("gave %d error %d\n",c,errno);
	return(0);
}

/*
 * mark dictionary info as modified
 */

dictmodify()
{
	filep->f_flags |= FDICTMOD;	/* mark it as modified	*/
}

/*
 * mktemprec -- allocate temporary record
 *
 *  make sure temprecord is at least one byte larger than recsize
 *  also round up to next 256 byte boundary so there won't
 *  be too many allocates for gradually increasing record sizes
 */

STATIC int mktemprec(recsize)
int recsize;
{
	if (temprsize <= recsize)
	    {
	    temprsize = (recsize + 0400) & ~0377;
	    tempisfd = -1;			/* temp rec is destroyed */
	    if (temprecord) free(temprecord);
	    if ((temprecord = malloc((unsigned) temprsize)) == NULL)
		{
		iserrno = ENOMEM;
		return(-1);
		}
	    }
	return(0);
}
